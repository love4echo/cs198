import React from 'react';


const defPage = () => {
  return (
    <div>
      <h2>My Website Yay!</h2>
    </div>
  );
};

export default defPage;